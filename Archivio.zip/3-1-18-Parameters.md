There are two kinds of parameters:
global parameters &#8211; used by any application
application parameters &#8211; defined at application level, so visible and accessible only at app level

Global parameters are valid for all the applications, whereas the scope of the application parameters is limited at application level.


                

---


