4WS.PLATFORM COMMUNITY EDITION INCLUDES A LARGE AMOUNT OF FEATURES, AVAILABLE WITH THE APP DESIGNER AND INTERPRETER
The app designer is used to graphically define the functionalities. The whole system is based on the MVC paradigm: database tables and relations are mapped to models, these can then be showed through different kinds of views, such as grids, trees, detail forms, and so forth. Controllers can be defined to capture events and to manage actions linked to views.
Click here for the Enterprise Edition user manualof 4WS.Platform

THE MAIN FEATURES PROVIDED BY THE APP DESIGNER

*  **Definition of data models and relations** 


---


