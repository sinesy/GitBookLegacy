Tree panels can load data from the server when expanding a node or by loading the whole tree when showing the tree.
When logging on the system, user authorizations are loaded too. In this way the application menu can adapt according to the user roles. Grid and form toolbars can adapt as well, according to the roles. It is possible to refine the editability of grid columns, if required.


                

---


