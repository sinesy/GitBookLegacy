4WS.Platform includes a series of wizards to quickly generate event bindings and actions for common scenarios.
In the following sections the available wizards are reported and described in deep.


                

---


