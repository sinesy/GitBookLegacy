In this chapter, the Web Modeler used to create processes will be described.
Not only the main features are reported, but also some best practises are included, in order to make it easy the definition of common processes.


                

---


