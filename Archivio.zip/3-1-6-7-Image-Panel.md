**In case of image** , the image definition panel is showed; through it the user has to define settings related to the image component:

* image title (optional, can be hidden)
* business component (for  **list of data** ) to link to the image;
* image width and height
* flags to show/hide border and to set panel opacity
* image field (database field containing the image name)
* image directory



                

---


