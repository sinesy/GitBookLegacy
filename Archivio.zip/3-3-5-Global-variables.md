4WS.Platform supports a series of variables available either on the client or on the server side.
These variables can be accessed and used within an action.
In the following sections there variables a reported, according to the tier.


                

---


