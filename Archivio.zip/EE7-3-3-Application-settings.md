Application settings define the behavior of the app, in terms of GUI and business logic.
Some of them are related specifically to the mobile app.
In the following sections these settings are reported in detail.


                

---


