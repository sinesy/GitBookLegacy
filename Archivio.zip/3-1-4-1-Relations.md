Data model definition includes also relations from this data model to other already defined data models. Each relation includes starting fields and ending fields on the other side of the relation.
Relations are useful to fetch data not limited to one table, but extended to a set of tables. They can be used also when inserting/deleting data, by storing data among multiple tables as a unique transactional task.


                

---


