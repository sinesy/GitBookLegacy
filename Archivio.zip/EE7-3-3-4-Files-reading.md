This is an optional field: if the field has been filled in with a command to process (e.g. a .sh or .bat command), then that command will be executed every time a device starts a sync process, in order to read data sent by the device to the central Platfom server.


                

---


