No hierarchical menu items can be showed the menu: all menu items must be part of a unique "plain" list, showed in one of the layouts reported above. Anyway, this is not a limit at all: moble apps cannot be as complex as the web applications, since the device display size and resources are limited.
A slide menu is similar to the one proposed in Facebook or GMail app.
The icon menu has a Google icon menu style.
The tab bar menu can be anchored to the top or the bottom, according to the hosting operating system: typically it is showed on the top for Android and on the bottom for iOS.


![](http://4wsplatform.org/wp-content/plugins../../uploads/media/copiadiplatformmobilemanual/image19.png)


Independently of the menu type, the transition form a window to another can happen through several events:
through a button (including the "Back" button used to get back to the parent window) included in the navigation bar, automatically showed if there is at least one other button defined for the navigation bar.


![](http://4wsplatform.org/wp-content/plugins../../uploads/media/copiadiplatformmobilemanual/image20.png)


via a button included within the window; in that case, the child window will be opened from this window and some parameters can be passed forward; this scenario requires to specify the child window name and parameters through a javascript action
through the tap (click) event on a row of the grid
swipe to delete a row in grid
long click on an element of the list / button.

                

---


