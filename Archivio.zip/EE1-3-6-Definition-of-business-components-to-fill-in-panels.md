For every imported object (described in the previous section), two business components are automatically created during the importing stage:

* a business component to read a list of documents
* a business component to read a single document


                

---


