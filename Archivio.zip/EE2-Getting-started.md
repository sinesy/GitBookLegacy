Learn how to use the main features of Platform


Fundamentals

Web Application creation.
How to create a web application using the App Designer and see it on the Web Interpreter.

Creation of a data report
How to define a query on the fly and create a readonly grid, retrieving data from it.

How to create a master-detail window
Starting from an already existing window containing a grid, show how to create a detail window and open it from a double click on a row of the grid.

Preview panel
How to add a preview panel to show images or other documents, linked to a detail form.

Adding buttons
How to add a button on a panel toolbar and execute custom logic when pressing it.

Linking windows
How to create a link between windows and pass values from the first to the second.

How to generate a PDF report
Using iReport to define a report template, upload the .jasper file and other files (e.g. images) and generate a PDF report

Mobile: working online
How to create an online functionality.



---


