In this section the most important elements of the process are reported and described:
START EVENTS
Start event
Start timer event
ACTIVITIES
User task
Service task
Mail task
Script task
STRUCTURAL
Event sub process
Call activity
GATEWAYS
Exclusive gateway
Parallel gateway
BOUNDARY EVENTS
Boundary timer event
END EVENTS
End event


                

---


