A server-side js action or a business component based on server-side javascript can be used to communicate with the Google services.
The "Server-side js" section reports all the js functions available. They include methods to read/send emails, manage contacts, manage calendar events, manage folders and files stored in Google Drive.


                

---


