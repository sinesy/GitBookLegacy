4WS.Platform Chat does not store personal information about the user.
Its aim is only to provide access to an interactive tool, which can help the web page visitor find what he is searching for and answer to very common questions and doubts.

                

---


