Optional field: if filled in, it represents the number of days to wait before deleting all old files produces by Platform Mobile Scheduler: sync log files, processed, sent.
                

---


