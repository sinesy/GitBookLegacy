Every time the app detail form is saved, the application version is incremented by one: this is helpful to expicitelly force the metadata synchronization on all the devices.

                

---


