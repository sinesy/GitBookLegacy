The first step is setting up the environment through the application parameters (Google Domain, admin account, private key, etc.). A Google Administrator is needed in order to successfully complete this task.

See the Identity Management section of Platform manual to figure out how to configure the environment.
Once completed the initial configuration, the Google server-side API can be invoked.


                

---


