This plugin allows to embed one or more windows configured through Platform into external web applications. This plugin not only manages the authentication between the external web application and Platform on the server side, but it manages events from the hosting app to the Platform window and the opposite. In this way the plugin offers a fully integration.


                

---


