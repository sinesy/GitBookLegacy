This tool allows to extract data structures, data and files stored in the Lotus Domino Forms.
In this way, Platform makes it possible to migrate from Lotus Notes and quickly create a new relational database, business logic and the web user interface.


                

---


