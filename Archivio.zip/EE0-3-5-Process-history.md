This window is similar to the window showing the process instances, but in the current one the processes reported are the ones already completed. For each of them, details are reported, including property values and completed tasks and the execution path.


                

---


