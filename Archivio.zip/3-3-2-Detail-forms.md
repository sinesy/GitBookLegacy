Detail forms can host input controls and labels, where controls can support any kind of data. Controls can be layout within multiple panels and folders. A toolbar to manage CRUD operations is linked to a form and it has the same operation of the grid toolbar.


                

---


