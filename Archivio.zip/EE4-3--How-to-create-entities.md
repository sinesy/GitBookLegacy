You can use the functionality "Objects" to create any number of entities. Just press the "New" button in the Objects window and select "Add an object to Datastore". This selection allows you to define a new object (a datastore entity), field by field.
The first step is to define the object name and save the object. At this point, the second folder, related to the object fields will be enabled and you can add any number of fields.
You have to define one (and only one) field as the primary key, i.e. the field which identifies the single record store in the entity.


                

---


