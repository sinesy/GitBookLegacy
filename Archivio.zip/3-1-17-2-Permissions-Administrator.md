Exist a rule of Permissions Administrator (PRMADMIN) that allows the manager permission to create, delete, assign and remove roles to users. You can assigne this role to one or more users.

                

---


