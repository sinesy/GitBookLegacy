This module includes a series of features related to communities and data sharing.
It consists of:

* a mail server integration
* integration with calendar (Microsoft and Google calendars are supported)
* activities and processes integration
* CMS integration for document management
* Lotus Domino migration tool
* The module provides a toolbar, which is composed of several buttons:
* send email
* calendar and activities
* documents
* activities and processes (connected to the BPM module)

                

---


