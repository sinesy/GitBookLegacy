You can define a rule to associate a role to list of users.


![](http://4wsplatform.org/wp-content/plugins../../uploads/media/copiadiplatformmanual_part3/image22.png)


Select the role and the users list to associate with. In the right, panel you can define two alternative rules:
Single interval: you can specify the start and the end date;
Multiple interval: you can select the day, the months and the years for define the rule.
You can remove the interval but you must selected the exact date for it.

                

---


