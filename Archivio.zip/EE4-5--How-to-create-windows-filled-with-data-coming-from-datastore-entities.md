Once created an object representing a datastore entity and a few business components linked to the object, you can create any number of panels which will compose a window.
A grid panel or a form panel can be fill in with data coming from business components linked to a datastore entity.
In this way, you can read and write data stored in the Google Datastore.


                

---


