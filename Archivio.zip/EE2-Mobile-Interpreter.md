MOBILE INTERPRETER FOR ANDROID AND iOS SUPPORTS THE MOST COMMON PANE CONTAINERS: CAROUSELS, TABS, NAVIGATOR. GRIDS, FORMS, FILTERS, MAPS, IMAGE PANES ARE SUPPORTED, AS FOR THE WEB VERSION.

OFF LINE
Offline apps are supported, through  **SqlLite**  database.
That means the user can access the app and its data even when there is not an Internet connection.
Offline state does not require to get web resources and data through the Net, so the app is quicker and more responsive.

---


