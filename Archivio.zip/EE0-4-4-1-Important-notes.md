Property Ids must respect a few naming rules:

*  **they have to contain only alphanumeric characters or the underscore symbol (_)** 
*  **the first character must be a letter** 
*  **they should be written in UPPERCASE** 



                

---


