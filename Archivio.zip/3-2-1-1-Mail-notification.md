One of the features provided by Groupware is the email notification. This functionality allows to send email messages starting from a panel; the Groupware toolbar optionally enabled per panel, can be used to send email messages. Default values for a message can be defined at panel level.
A message includes the following data:

* subject
* destination: list of email addresses
* cc: list of email addresses
* bcc: list of email addresses
* body: a message expressed in HTML format
* attachments: a list of documents attached to the message, coming from the CMS sub-system system.

                

---


