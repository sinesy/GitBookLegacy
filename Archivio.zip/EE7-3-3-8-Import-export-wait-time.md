if specified, it represents wait time (expressed in seconds) after which all processes will be executed, on a regular basis. It is used together with "Import/export start time".
if not specified, it is assumed a wait time of 1 hour.


                

---


