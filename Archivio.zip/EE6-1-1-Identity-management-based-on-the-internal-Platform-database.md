This represents the simplest configuration: there aren’t external authentication systems involved and consequently the user credentials are all stored in the Plaform database.

No additional configutation is required.
                

---


