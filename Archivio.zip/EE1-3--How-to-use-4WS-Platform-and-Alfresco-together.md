Once installed Alfresco CMS and set the ADMIN password, the same password must be set for 4WS.Platform too. Both systems must also share the same identity management system: in this way the use the same set of users and groups.
                

---


