![](http://4wsplatform.org/wp-content/uploads/2016/01/4wsplatform-roadmap-january-2016.png)
                  4WS.PLATFORM IS EVOLVING DAY BY DAY
At the moment, the web version of the product is already available and fully operating.


COMMUNITY EDITION

* Java 8
* Apache Tomcat 8
* Drag ‘n drop UI designer


---


