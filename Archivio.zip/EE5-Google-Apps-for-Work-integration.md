The Google Apps for Work integration lets the user interact with their Google Account or Google Apps Domain, depending on how the configuration is done.
The integrated tools are:

* GMail
* Google Calendar
* Google Contacts
* Google Directory
* Google Drive


See the details on the specific page.
                

---


