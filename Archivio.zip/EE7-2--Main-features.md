4WS.Platform for mobile apps is composed of the mobile interpreter (the app to run) and the server-side Platform installation (the same used by the web interpreted applications.)
The main features of the product can then be split up in two parts: the ones offered by the mobile app and the ones provided in the server-side Platform installation.


                

---


