A service task represents an automatic activity, carried out automatically by the BPM engine.
A few utility classes are provided by 4WS.Platform, in order to make it easier and faster the definition of complex processes including SQL stataments to execute for reading or writing data into a database or to call a web service available in 4WS.Platform or in another web server.


                

---


