4WS.PLATFORM HAS BEEN DEVELOPED ABOVE AN OPEN SOURCE SDK, CALLED WARP

 **WARP ** is a  **Java based**   **framework ** that can be used to develop rich web applications, based on JPA, JDBC, EJB, Java Beans, JAX-RS, ExtJS technologies **. ** 
 **WARP**  is an  **open source project**  powered by Sinesy and available through SourceForge portal at this link.

---


