REQUIREMENTS AND STEPS TO FOLLOW


REQUIREMENTS
Requirements related to the Community Edition are:

* Eclipse Java EE IDE is recommended. Try 3.5 or above with Java 7 installed.
* An SVN plugin for Eclipse is recommended.
* You can use any kind of OS: Windows, Linux or MacOS.
* A development database schema is also required; the supported databases are: Oracle, MySQL, MS SQLServer, PostgreSQL


---


