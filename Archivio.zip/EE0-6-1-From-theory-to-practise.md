Now it is time to move from theory to a real example of how to manage processes through 4WS.Platform, which makes it possible to graphically design a business process and monitor its execution, step by step, until its end.

Let’s start from the Administration -&gt; Activiti menu available in the 4WS.Platform App Designer. This menu is composed of these functionalities, all related to the BPM management:
Processes
Instances
To do list
History


                

---


