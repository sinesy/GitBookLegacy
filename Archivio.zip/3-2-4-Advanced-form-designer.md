The advanced form designer is used to graphically design a form, using drag &#8216;n drop techniques and a components palette, to speed up and make easier the development of complex forms, including folders, subfolders and subpanes.
This module can be used together with or in alternative with the default form designer provided with 4WS.Platform Community Edition, based on an editable table of controls.


                

---


