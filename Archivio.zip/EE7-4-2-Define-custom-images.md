Copy into the web.context folder linked to the mobile application all images required by the mobile app (i.e. "platform//images); examples of images are:
 **btn_menu** .png and  **btn_menu@2x** .png &#8211; icon showed on the top left of the app (the blu lego brick)
 **back** .png and  **back@2x** .png &#8211; icon for the "back" button
 **save** .png and  **save@2x** .png &#8211; icon for the "save" button (both for insert or edit operations)
 **filter** .png and ** filter@2x** .png and  **lista** .png and  **lista@2x** .png &#8211; icon for "show/hide filter" on a grid
 **delete** .png and  **delete@2x** .png &#8211; icon for the "delete" button
 **add** .png and  **add@2x** .png &#8211; icon for add a new detail button
 **close_lookup** .png and  **close_lookup@2x** .png &#8211; icon for closing the current window
 **upload** .png and  **upload@2x** .png &#8211; icon for the "upload image" button.




                

---


