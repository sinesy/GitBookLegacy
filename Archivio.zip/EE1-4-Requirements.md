In order to use this integration, the following requirements must be respected:

* Java 1.7.x
* Alfresco 4.2-c
* 4WS.Platform Enterprise Edition, including the Documents Management module

                

---


