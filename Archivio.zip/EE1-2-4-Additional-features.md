Additional features supported in 4WS.Platform are
tagging of a document
rating of a document

These features can be enabled in a grid panel definition, through the ad hoc checkboxes available in that pane.
                

---


