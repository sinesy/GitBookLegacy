Every completed process is showed within the History functionality, whose operation is similar to the Instances feature.

                                    
                                    
                

---


