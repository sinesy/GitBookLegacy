Creating apps for Android and iOS environments is very different and must be managed according to the rules defined by these vendors.
In the following sections the two platform are described separately.


                

---


