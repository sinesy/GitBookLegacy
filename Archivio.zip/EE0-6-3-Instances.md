After starting a process, the process execution is showed in the instances list, which is composed of 3 sections:
Process versions, reporting the versioned processes list, having at least one active instance; 
Process executions, showing all active instances or only instances related to the selected process in the first list;
the detail pane on the right reports several information about the process execution: the graphical representation of the process and the exact task currently in execution/waiting state; for that task, several information are available: name, process, assignee, expiration time, as well as the process and task variables with their value.

                                    
                                    



                

---


