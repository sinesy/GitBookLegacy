Alfresco and 4WS.Platform must share the same users and groups. Both products support the identity management based on an LDAP server.
If your organization already has an LDAP internally, you can configure manually Alfresco in order to connect it to that LDAP; the same settings must be reported as global parameters in 4WS.Platform.

                

---


