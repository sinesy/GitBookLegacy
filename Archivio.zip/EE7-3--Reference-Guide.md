In this chapter, a set of helpful information is provided when configuring a new mobile app through the Web Designer.


                

---


