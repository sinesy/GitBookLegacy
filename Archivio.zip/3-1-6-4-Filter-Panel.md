**In case of filter+grid,**  in addition to the grid definition, the filter panel must be defined; through its definition pane the user has to define settings related to the filter component:

* filter title (optional, can be hidden)
* flags to show/hide border and to set panel opacity
* filter width and height
* text for search and clear buttons
* number of columns and label length, used to define the labels+controls layout; it is also possible to arrange lables and controls by specifying the x and y coordinates for each of them.



                

---


